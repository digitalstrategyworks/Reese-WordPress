
//Name: reesenews.org weather widget 1.0

//Description: A weather widget using the weather.com xml service, based on HTML, CSS, and JQuery.
//Copyright (C) 2010  Reese Felts Digital News Project - University of North Carolina at Chapel Hill
//This program is free software: you can redistribute it and/or modify
//it under the terms of the GNU General Public License as published by
//the Free Software Foundation, either version 3 of the License, or
//(at your option) any later version.

//This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
//along with this program.  If not, see http://www.gnu.org/licenses/.

//Contact Information:

//Reese Felts Digital News Project (reesenews.org)
// School of Journalism and Mass Communication
//University of North Carolina at Chapel Hill
//11 Carroll Hall - CB 3365
//Cameron Avenue
//Chapel Hill, NC 27599
//Tel. 919-962-2017
//Web: http://www.reesefelts.org, http://www.reesenews.org
//Contact 1: Tony Zeoli, Lead Developer, email: tonyzeoli@reesnews.org
//Contact 2: Seth Wright, Platform Developer, email: sethwright@reesenews.org

-------------------------------------------------------------------------------------------------------

Included Files:

images
index.php
jquery-1.4.2.js
ReadMe
weather-icons
weather.php

-------------------------------------------------------------------------------------------------------

Instructions for Use:

The first step to creating this weather drop-down was  to get an XML document provided by Weather.com. I parsed this file using  <a title="PHP SimpleXMLElement" href="http://php.net/manual/en/class.simplexmlelement.php" target="_blank">PHP SimpleXMLElement.</a> I struggled with learning how to parse an XML  document at first, and I saw that some people parsed XML using string searches. SimpleXMLElement is the quickest and easiest way to process an XML file using PHP. It allows you to sort through XML like you would an array.

[php]$data = file_get_contents($uri);
$weather = new SimpleXMLElement($data);
$hi_temperature = $weather->dayf->day[0]->hi;
[/php]

This statement declares a JavaScript variable (below) called <em>data</em> that pulls the XML from the <a title="Weather.com API" href="http://www.weather.com/services/xmloap.html" target="_blank">Weather.com API.</a>

$uri

I then turn the data into a  SimpleXMLElement, which allows it to be treated much like an array.

In PHP, to select array positions use the following characters:

->

I use the PHP <code>echo</code> language construct to add HTML from the PHP file. This creates the basic structure of the weather drop-down. There will be a box at the top, which displays the current temperature and corresponding weather icon:

#current_conditions

When the user clicks on this box, there will be another box that drops down:

#weatherDrawer

Resulting in three smaller boxes:

#weatherTop
#forecast
#weatherBottom

To include this PHP file in our index.php, where the rest of our code lies, make sure to wrap this statement inside PHP tags:

include 'weather.php'

The reason #weatherDrawer is made of three boxes is so that we can use CSS  to create a menu feel. #weatherTop and #weatherBottom both have  background-image set to a .png file and do not repeat. However,  #forecast has a repeat-y and is only a few pixels high so all of the  content can fill in as needed.

Finally, we need to program the jQuery action that creates the drop down effect of the weather drawer. First, I link the jQuery source file in the head of my document, and for convenience, I used an inline script:

$("div#weatherDrawer").hide();
$("div#current_conditions").click(
function () {
$("div#weatherDrawer").stop(true, true).slideToggle();
}
);


This  script tells the #weatherDawer to be hidden initially. The three div's inside the #weatherDrawer will each be hidden.

Then on the click of the  current conditions, the weatherDrawer will slideToggle. SlideToggle is the animation effect built into jQuery that creates the drawer-like  feel.

We're happy to share the code and files to those who have expressed interest in how this weather experience was created. This work is licensed under Creative Commons with attribution. The sticky notes we use on reesenews.org are available for purchase at iStockPhoto.com.

Office environment weather theme sticky note
http://www.istockphoto.com/stock-photo-9495357-office-environment-weather-theme-sticky-note.php

