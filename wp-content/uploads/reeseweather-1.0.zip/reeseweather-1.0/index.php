<?php

/*

Name: reesenews.org weather widget
Description: A weather widget using the weather.com xml service, based on HTML, CSS, and JQuery.
Copyright (C) 2010  Reese Felts Digital News Project - University of North Carolina at Chapel Hill
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
 
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
 
You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Contact Information:
 
Reese Felts Digital News Project (reesenews.org)
School of Journalism and Mass Communication
University of North Carolina at Chapel Hill
11 Carroll Hall - CB 3365
Cameron Avenue
Chapel Hill, NC 27599
Tel. 919-962-2017
Web: http://www.reesefelts.org, http://www.reesenews.org
Contact 1: Tony Zeoli, Lead Developer, email: tonyzeoli@reesenews.org
Contact 2: Seth Wright, Multi-Platform Developer, email: seth.wright@reesenews.org

*/
?>

<!DOCTYPE html>
<html>

<head>
	
	<!-- we need jquery to do the dropdown animation -->
	<script type="text/javascript" src="jquery-1.4.2.js"></script>
	
	<style>
	
	/* these are the various styles that make the weather look like it does */
	*{
		font-family: verdana, sans-serif;
		font-size: 1em;
	}
	
	div#current_conditions {
		padding-top:3px;
		margin-bottom:0px;
		border:1px dotted #000;
		width: 100px;
		padding: 5px;
	}
	
	/* make the text go to the middle of the weather note */
	#current_conditions span {
		position:relative;
		top: -20px;
	}
	
	#current_conditions p.degrees{
		position: relative;
		top: 45px;
		right: 55px;
	}
	
	div.weather {
		text-align: center;
		color: #759EC7;
	}
	
	#weatherDrawer {
		z-index: 1000;
	}
	
	
	/* this is what creates the effect of a iPad dropdown. i specify absolute width and height of everything but the forecast. they are the exact height and width of the .png files. the middle repeats, making it have as much room as needed */
	#weatherTop {
		width: 100px;
		height: 92px;
		background-image: url('../images/weatherTop.png');
	}
	
	#forecast {
		width: 100px;
		background-image: url('../images/weatherMiddle.png');
		height: auto;
		background-repeat: repeat-y;
		font-size:0.9em;
	}
	
	#weatherBottom {
		height: 50px;
		width: 100px;
		background-image: url('../images/weatherBottom.png');
		background-repeat: no-repeat;
	}
	
	/* colors */
	span.red{
		color: #A44F2B;
	}
	span.blue {
		color: #759EC7;
	}
	span.black {
		color: #000;
	}
	
	</style>

</head>
<body>
	
	<?php 
	// this is how we bring in the weather file that i wrote
	
	include 'weather.php' 
	
	?>
	
	<!-- this script runs the weather click animation. it must be below where we include the weather file to register. you could change it to have a $(document).ready otherwise. -->
	
	<script>
		$("div#weatherDrawer").hide();
			
		$("div#current_conditions").click(
		  function () {
			$("div#weatherDrawer").stop(true, true).slideToggle();
		  }
		);
		
	</script>
	
</body>

</html>